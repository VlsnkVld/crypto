https://github.com/vuetifyjs/vuetify/tree/master/packages/vuetify/src/styles/settings

https://vuetifyjs.com/en/directives/resize/#usage

https://apexcharts.com/docs/options/grid/
https://apexcharts.com/vue-chart-demos/line-charts/gradient/

https://fonts.google.com/specimen/Rubik?query=Rubik

https://www.npmjs.com/package/country-code-emoji
https://www.npmjs.com/package/libphonenumber-js

https://remixicon.com/

https://vue-mention.netlify.app/

https://www.npmjs.com/package/string-to-color
