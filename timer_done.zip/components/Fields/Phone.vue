<template>
  <v-text-field
    :value="rawValue"
    :rules="rules"
    type="text"
    inputmode="tel"
    :name="name"
    :label="label"
    :hint="hint"
    :placeholder="placeholder"
    :error-messages="errorMessages"
    outlined
    @click:append="toggleShow"
    @input="input"
  >
    <template #append>
      <span class="pt-1">{{ countryFlag }}</span>
    </template>
  </v-text-field>
</template>

<script>
import parsePhoneNumber from 'libphonenumber-js'
import { countryCodeEmoji } from 'country-code-emoji'

export default {
  name: 'PhoneField',
  props: {
    value: {
      type: String,
      default: () => '',
    },
    name: {
      type: String,
      default: () => 'phone',
    },
    rules: {
      type: Array,
      default: () => [],
    },
    label: {
      type: String,
      default() {
        return this.$t('fields.phone.title.default')
      },
    },
    placeholder: {
      type: String,
      default: () => '+x (xxx) xxx-xx-xx',
    },
    hint: {
      type: String,
      default: () => null,
    },
    errorMessages: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      rawValue: '',
      defaultCountryFlag: '🏳',
      countryFlag: '🏳',
    }
  },
  methods: {
    input(rawValue) {
      const phone = parsePhoneNumber(rawValue)

      this.rawValue = rawValue
      this.countryFlag = phone?.country
        ? countryCodeEmoji(phone?.country)
        : this.defaultCountryFlag

      this.$emit('input', phone?.number)
    },
    toggleShow() {
      this.show = !this.show
    },
  },
}
</script>
