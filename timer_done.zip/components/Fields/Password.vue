<template>
  <v-text-field
    :value="value"
    :append-icon="show ? '$eyeOff' : '$eyeOn'"
    :rules="rules"
    :type="show ? 'text' : 'password'"
    :name="name"
    :label="label"
    :hint="hint"
    :placeholder="placeholder"
    :error-messages="errorMessages"
    outlined
    @click:append="toggleShow"
    @input="(value) => $emit('input', value)"
  />
</template>

<script>
export default {
  name: 'PasswordField',
  props: {
    value: {
      type: String,
      default: () => '',
    },
    name: {
      type: String,
      default: () => 'password',
    },
    rules: {
      type: Array,
      default: () => [],
    },
    label: {
      type: String,
      default() {
        return this.$t('fields.password.title.default')
      },
    },
    placeholder: {
      type: String,
      default: () => null,
    },
    hint: {
      type: String,
      default: () => null,
    },
    errorMessages: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      show: false,
    }
  },
  methods: {
    toggleShow() {
      this.show = !this.show
    },
  },
}
</script>
