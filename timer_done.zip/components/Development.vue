<template>
  <v-card class="mx-auto bg--brand mt-10 mb-5" max-width="344">
    <v-card-text>
      <v-row>
        <v-col>
          <h6 class="text-h6 text-left">We are in development 🛠</h6>
          <p class="mt-2">This feature will be available soon</p>
        </v-col>
        <v-col cols="auto">
          <img
            src="~/static/images/robot-developer.svg"
            alt="Robot developer"
          />
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  name: 'Development',
}
</script>
