<template>
  <div class="logo">
    <span class="primary--text">Bitcy</span>
    <span class="white--text">Bets</span>
  </div>
</template>

<script>
export default {
  name: 'Logo',
}
</script>

<style lang="scss">
.logo {
  display: inline-flex;
  font-weight: 900;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}
</style>
